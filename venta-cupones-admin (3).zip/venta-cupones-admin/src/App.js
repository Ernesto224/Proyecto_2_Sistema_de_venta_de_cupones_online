import './App.css';
import { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import PaginaPrincipal from './Components/PaginaPrincipal';
import InicioSesion from './Components/InicioSesion';
import BarraMenu from './Components/BarraMenu';

function App() {
  const [estadoPagina, setEstadoPagina] = useState(null);

  return (
    <div className="App">
      {estadoPagina === 'Sesion' ? (
        <>
        </>
      ) : estadoPagina === 'PaginaPrincipal' ? (
        <>
          <BarraMenu estadoPagina={estadoPagina} setEstadoPagina={setEstadoPagina} />
          <header className="App-header">
            <PaginaPrincipal setEstadoPagina={setEstadoPagina} estadoPagina={estadoPagina} />
          </header>
        </>
      ) : (
        <>
          <header className="App-header">
            <InicioSesion estadoPagina={estadoPagina} setEstadoPagina={setEstadoPagina} />
          </header>
        </>
      )}
    </div>
  );
}

export default App;
