import React, { useState } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
export default function InicioSesion(props) {
    const { estadoPagina, setEstadoPagina } = props;
    const [datosUsuario, setDatosUsuario] = useState({
        NombreUsuario: '',
        Contrasenia: ''
    });
    const handleChange = e => {
        const { name, value } = e.target;
        setDatosUsuario(prevState => ({
            ...prevState,
            [name]: value
        }));
    };
    const baseUrl = 'http://localhost/VentaCuponesPHP.API/Presentation/UsuarioAdminLecturaController.php';
    const iniciarSesion = async () => {
        const f = new FormData();
        console.log(datosUsuario.NombreUsuario + " " + datosUsuario.Contrasenia);
        f.append("NombreUsuario", datosUsuario.NombreUsuario);
        f.append("Contrasenia", datosUsuario.Contrasenia);
        f.append("METHOD", "POST");
        await axios.post(baseUrl, f, { params: { NombreUsuario: datosUsuario.NombreUsuario, Contrasenia: datosUsuario.Contrasenia } })
            .then(response => {
                if (response) {
                    setEstadoPagina('PaginaPrincipal');
                }
            }).catch(error => {
                console.log(error);
            });
    };
    return (
        <div className="container">
            <div className="row justify-content-center align-items-center vh-100">
                <div className="col-md-4">
                    <div className="card p-4 shadow">
                        <div className="text-center mb-4">
                            <div className="mb-3">
                                <img
                                    src="path_to_your_icon"
                                    alt="User Icon"
                                    style={{ width: '50px', height: '50px' }}
                                />
                            </div>
                            <h1>Iniciar Sesión</h1>
                        </div>
                        <input
                            className="form-control mb-3"
                            name="NombreUsuario"
                            type="text"
                            placeholder="Nombre Usuario"
                            onChange={handleChange}
                        />
                        <input
                            className="form-control mb-3"
                            name="Contrasenia"
                            type="password"
                            placeholder="Contraseña"
                            onChange={handleChange}
                        />
                        <button className="btn btn-success w-100" onClick={iniciarSesion}>
                            Ingresar
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );

}