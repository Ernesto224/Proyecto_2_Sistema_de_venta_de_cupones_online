import React, { useState, useEffect } from 'react';
import { Modal, ModalBody, ModalFooter, ModalHeader } from 'reactstrap';
import axios from 'axios';

export default function ModalDetalleEmpresa(props) {
    const { empresaSeleccionada, setEmpresaSeleccionada } = props;
    const { empresas, setEmpresas } = props;
    const { editarEmpresa, setEditarEmpresa } = props;

    const handleChange = (e) => {
        const { name, value } = e.target;

        setEmpresaSeleccionada((prevState) => ({
            ...prevState,
            [name]: value,
        }));
    };

    const editarDatosEmpresa = async () => {
        if (validarCampos()) {
            const baseUrl1 = 'http://localhost/VentaCuponesPHP.API/Presentation/EmpresaModificarController.php';
            var f = new FormData();
            f.append("IDEmpresa", empresaSeleccionada.IDEmpresa);
            f.append("NombreEmpresa", empresaSeleccionada.NombreEmpresa);
            f.append("DireccionFisica", empresaSeleccionada.DireccionFisica);
            f.append("CedulaFisicaJuridica", empresaSeleccionada.CedulaFisicaJuridica);
            f.append("FechaCreacion", empresaSeleccionada.FechaCreacion);
            f.append("CorreoElectronico", empresaSeleccionada.CorreoElectronico);
            f.append("Telefono", empresaSeleccionada.Telefono);
            f.append("NombreUsuario", empresaSeleccionada.NombreUsuario);
            f.append("Contrasenia", empresaSeleccionada.Contrasenia);
            f.append("Habilitado", empresaSeleccionada.Habilitado);
            f.append("CredencialesTemporales", empresaSeleccionada.CredencialesTemporales);
            f.append("METHOD", "PUT");
            await axios.post(baseUrl1, f, { params: { IDEmpresa: empresaSeleccionada.IDEmpresa } })
                .then(response => {
                    var dataNueva = empresas;
                    dataNueva.map(empresa => {
                        if (empresa.IDEmpresa === empresaSeleccionada.IDEmpresa) {
                            empresa.NombreEmpresa = empresaSeleccionada.NombreEmpresa;
                            empresa.DireccionFisica = empresaSeleccionada.DireccionFisica;
                            empresa.CedulaFisicaJuridica = empresaSeleccionada.CedulaFisicaJuridica;
                            empresa.FechaCreacion = empresaSeleccionada.FechaCreacion;
                            empresa.CorreoElectronico = empresaSeleccionada.CorreoElectronico;
                            empresa.Telefono = empresaSeleccionada.Telefono;
                            empresa.NombreUsuario = empresaSeleccionada.NombreUsuario;
                            empresa.Contrasenia = empresaSeleccionada.Contrasenia;
                            empresa.Habilitado = empresaSeleccionada.Habilitado;
                        }
                    });
                    setEmpresas(dataNueva);
                    abrirCerrarModalEditar();
                }).catch(error => {
                    console.log(error);
                });
        } else {
            alerts('Datos inválidos');
        }
    }

    const abrirCerrarModalEditar = () => {
        setEditarEmpresa(!editarEmpresa);
    };

    const validarCampos = () => {
        return validarNombreEmpresa(empresaSeleccionada.NombreEmpresa) &&
            validarDireccionFisica(empresaSeleccionada.DireccionFisica) &&
            (validarCedulaFiscal(empresaSeleccionada.CedulaFisicaJuridica) ||
                validarCedulaJuridica(empresaSeleccionada.CedulaFisicaJuridica)) &&
            validarCorreoElectronico(empresaSeleccionada.CorreoElectronico) &&
            validarTelefono(empresaSeleccionada.Telefono) &&
            validarNombreUsuario(empresaSeleccionada.NombreUsuario) &&
            validarContrasenia(empresaSeleccionada.Contrasenia);
    }

    const validarNombreEmpresa = (nombre) => {
        return /^[a-zA-Z\s]{2,200}$/.test(nombre);
    };

    const validarDireccionFisica = (direccion) => {
        return /^[a-zA-Z\s]{30,200}$/.test(direccion);
    };

    const validarCedulaFiscal = (cedula) => {
        return /^\d{2}-\d{4}-\d{4}$/.test(cedula);
    };

    const validarCedulaJuridica = (cedula) => {
        return /^\d{2}-\d{3}-\d{6}$/.test(cedula);
    };

    const validarCorreoElectronico = (correoElectronico) => {
        return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(correoElectronico);
    };

    const validarTelefono = (telefono) => {
        return /^\d{4}-\d{4}$/.test(telefono);
    };

    const validarNombreUsuario = (nombreUsuario) => {
        return /^[a-zA-Z\s]{3,20}$/.test(nombreUsuario);
    };

    const validarContrasenia = (contrasenia) => {
        return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])([A-Za-z\d$@$!%*?&]|[^ ]){8,16}$/.test(contrasenia);
    };

    const alerts = (mensaje) => {
        alert(mensaje);
    };

    return (
        <div>
            <Modal isOpen={editarEmpresa}>
                <ModalHeader className="bg-secondary text-white">Editar Empresa</ModalHeader>
                <ModalBody>
                    <div className="form-group">
                        <label>ID: </label>
                        <br />
                        <input type="text" className="form-control" name="IDEmpresa" value={empresaSeleccionada && empresaSeleccionada.IDEmpresa} readOnly />
                        <br />
                        <label>Nombre Empresa: </label>
                        <br />
                        <input type="text" className="form-control" name="NombreEmpresa" onChange={handleChange} value={empresaSeleccionada && empresaSeleccionada.NombreEmpresa} maxLength={200} />
                        <br />
                        <label>Dirección Física: </label>
                        <br />
                        <input type="text" className="form-control" name="DireccionFisica" onChange={handleChange} value={empresaSeleccionada && empresaSeleccionada.DireccionFisica} maxLength={200} />
                        <br />
                        <label>Cédula Física Jurídica: </label>
                        <br />
                        <input type="text" className="form-control" name="CedulaFisicaJuridica" onChange={handleChange} value={empresaSeleccionada && empresaSeleccionada.CedulaFisicaJuridica} maxLength={12} />
                        <br />
                        <label>Fecha Creación: </label>
                        <br />
                        <input type="date" className="form-control" name="FechaCreacion" onChange={handleChange} value={empresaSeleccionada && empresaSeleccionada.FechaCreacion} />
                        <br />
                        <label>Correo Electrónico: </label>
                        <br />
                        <input type="text" className="form-control" name="CorreoElectronico" onChange={handleChange} value={empresaSeleccionada && empresaSeleccionada.CorreoElectronico} />
                        <br />
                        <label>Teléfono: </label>
                        <br />
                        <input type="text" className="form-control" name="Telefono" onChange={handleChange} value={empresaSeleccionada && empresaSeleccionada.Telefono && empresaSeleccionada.Telefono.replace(/(\d{4})(\d{4})/, '$1-$2')} pattern="[0-9]{4}-[0-9]{4}" maxLength={9} />
                        <br />
                        <label>Nombre Usuario: </label>
                        <br />
                        <input type="text" className="form-control" name="NombreUsuario" onChange={handleChange} value={empresaSeleccionada && empresaSeleccionada.NombreUsuario} maxLength={20} />
                        <br />
                        <label>Contraseña: </label>
                        <br />
                        <input type="text" className="form-control" name="Contrasenia" onChange={handleChange} value={empresaSeleccionada && empresaSeleccionada.Contrasenia} maxLength={16} />
                        <br />
                        <label>Habilitado: </label>
                        <br />
                        <input
                            type="checkbox"
                            className="form-check-input"
                            name="Habilitado"
                            checked={empresaSeleccionada && empresaSeleccionada.Habilitado === 1}
                            onChange={(e) => handleChange({ target: { name: 'Habilitado', value: e.target.checked ? 1 : 0 } })}
                        />
                        <br />
                        <label>Credenciales Temporales: </label>
                        <br />
                        <input type="text" className="form-control" name="CredencialesTemporales" onChange={handleChange} value={empresaSeleccionada && empresaSeleccionada.CredencialesTemporales} />
                        <br />
                    </div>
                </ModalBody>
                <ModalFooter>
                    <button className="btn btn-primary" onClick={() => editarDatosEmpresa()}>Editar</button>{"   "}
                    <button className="btn btn-danger" onClick={() => abrirCerrarModalEditar()}>Cancelar</button>
                </ModalFooter>
            </Modal>
        </div>
    );
}
