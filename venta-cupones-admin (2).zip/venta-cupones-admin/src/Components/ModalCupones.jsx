import React, { useState } from "react";
import '../App.css';
import ModalEditarCupon from "./ModalEditarCupon";
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import ModalCrearCupon from "./ModalCrearCupon";

export default function ModalCupones(props) {
    const { empresaSeleccionada, setEmpresaSeleccionada } = props;
    const { Cupones, setCupones } = props;
    const { detalleCupon, setDetalleCupon } = props;
    const [editarCupon, setEditarCupon] = useState(false);
    const [crearCupon, setCrearCupon] = useState(false);
    const { categorias, setCategorias } = props;
    const [cuponSeleccionado, setCuponSeleccionado] = useState({
        IDCupon: '',
        Nombre: '',
        Imagen: '',
        Ubicacion: '',
        PrecioCupon: '',
        IDEmpresa: '',
        IDCategoria: '',
        Habilitado: ''
    });

    const abrirCerrarDetalleCupon = () => {
        setDetalleCupon(!detalleCupon);
    };

    const abrirCerrarModalCrearCupon = () => {
        setCrearCupon(!crearCupon);
    };

    const eliminarCuponDELETE = async (cupon) => {
        setCuponSeleccionado(cupon);
        const baseUrl1 = 'http://localhost/VentaCuponesPHP.API/Presentation/CuponModificarController.php';
        var f = new FormData();
        f.append("IDCupon", cupon.IDCupon);
        f.append("METHOD", "DELETE");
        console.log(cupon.IDCupon);

        try {
            const response = await axios.post(baseUrl1, f, { params: { IDCupon: cupon.IDCupon } });
            console.log(response);
            setCupones(Cupones.map(cuponAux => {
                if (cuponAux.IDCupon === cupon.IDCupon) {
                    return { ...cuponAux, Habilitado: 0 };
                }
                return cuponAux;
            }));
        } catch (error) {
            console.log(error);
        }
    };

    const abrirCerrarEdicionCupon = (cupon) => {
        setCuponSeleccionado(cupon);
        setEditarCupon(!editarCupon);
    };

    return (
        <>
            <div className="seccion-cupones" style={{ backgroundColor: '#5c5c5c', color: 'white', padding: '20px', borderRadius: '10px' }}>
                <h2 style={{ color: 'white' }}>Detalle de Cupón</h2>
                <div className="table-responsive" style={{ maxHeight: '70vh' }}>
                    <table className="table table-striped table-bordered" style={{ backgroundColor: '#878787', color: 'white' }}>
                        <thead className="thead-dark" style={{ backgroundColor: '#787878' }}>
                            <tr>
                                <th>Nombre</th>
                                <th>Imagen</th>
                                <th>Ubicación</th>
                                <th>PrecioCupon</th>
                                <th>Empresa</th>
                                <th>Categoría</th>
                                <th>Habilitado</th>
                                <th>Editar</th>
                                <th>Eliminar</th>
                            </tr>
                        </thead>
                        <tbody style={{ overflowY: 'auto' }}>
                            {Cupones.map((cupon) => (
                                <tr key={cupon.IDCupon}>
                                    <td>{cupon.Nombre}</td>
                                    <td>
                                        {cupon.Imagen ? <img src={cupon.Imagen} alt={cupon.Nombre} style={{ width: '100px', height: '100px' }} /> : 'Sin imagen'}
                                    </td>
                                    <td>{cupon.Ubicacion}</td>
                                    <td>{cupon.PrecioCupon}</td>
                                    <td>{cupon.IDEmpresa === empresaSeleccionada.IDEmpresa ? empresaSeleccionada.NombreEmpresa : 'No tiene'}</td>
                                    <td>
                                        {categorias.find(categoria => categoria.IDCategoria === cupon.IDCategoria)?.Nombre || 'Categoría no encontrada'}
                                    </td>

                                    <td>{cupon.Habilitado ? 'Sí' : 'No'}</td>
                                    <td>
                                        <button className="btn btn-primary mr-2" style={{ backgroundColor: '#787878', borderColor: '#5c5c5c', color: 'white' }} onClick={() => abrirCerrarEdicionCupon(cupon)}>Editar</button>
                                    </td>
                                    <td>
                                        <button className="btn btn-danger" style={{ backgroundColor: '#d9534f', borderColor: '#d43f3a', color: 'white' }} onClick={() => eliminarCuponDELETE(cupon)} disabled={cupon.Habilitado !== 1}>Eliminar</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                <br />
                <button className="btn btn-secondary" style={{ backgroundColor: '#b1b1b1', borderColor: '#787878', color: 'white' }} onClick={abrirCerrarDetalleCupon}>Cerrar</button>
                <button className="btn btn-secondary" style={{ backgroundColor: '#b1b1b1', borderColor: '#787878', color: 'white' }} onClick={abrirCerrarModalCrearCupon}>Crear Cupon</button>
            </div>

            {editarCupon && (
                <ModalEditarCupon
                    Cupones={Cupones} setCupones={setCupones}
                    detalleCupon={detalleCupon} setDetalleCupon={setDetalleCupon}
                    editarCupon={editarCupon} setEditarCupon={setEditarCupon}
                    cuponSeleccionado={cuponSeleccionado} setCuponSeleccionado={setCuponSeleccionado}
                />
            )}

            {crearCupon && (
                <ModalCrearCupon
                    Cupones={Cupones} setCupones={setCupones}
                    detalleCupon={detalleCupon} setDetalleCupon={setDetalleCupon}
                    crearCupon={crearCupon} setCrearCupon={setCrearCupon}
                    empresaSeleccionada={empresaSeleccionada} setEmpresaSeleccionada={setEmpresaSeleccionada}
                    categorias={categorias} setCategorias={setCategorias}
                />
            )}
        </>
    );
}
