import React, { useState } from "react";
import axios from 'axios';
export default function InicioSesion(props) {
    const { estadoPagina, setEstadoPagina } = props;
    const [datosUsuario, setDatosUsuario] = useState({
        NombreUsuario: '',
        Contrasenia: ''
    });
    const handleChange = e => {
        const { name, value } = e.target;
        setDatosUsuario(prevState => ({
            ...prevState,
            [name]: value
        }));
    };
    const baseUrl = 'http://localhost/VentaCuponesPHP.API/Presentation/UsuarioAdminLecturaController.php';
    const iniciarSesion = async () => {
        const f = new FormData();
        console.log(datosUsuario.NombreUsuario + " " + datosUsuario.Contrasenia);
        f.append("NombreUsuario", datosUsuario.NombreUsuario);
        f.append("Contrasenia", datosUsuario.Contrasenia);
        f.append("METHOD", "POST");
        await axios.post(baseUrl, f, { params: { NombreUsuario: datosUsuario.NombreUsuario, Contrasenia: datosUsuario.Contrasenia } })
            .then(response => {
                if (response) {
                    setEstadoPagina('PaginaPrincipal');
                }
            }).catch(error => {
                console.log(error);
            });
    };
    return (
        <div className="inicio-sesion">
            <h1>Iniciar Sesión</h1>
            <input className='input-text' name="NombreUsuario" type='text' placeholder='Nombre Usuario' onChange={handleChange}></input>
            <input type='input-text' name="Contrasenia" placeholder='Contraseña' onChange={handleChange}></input>
            <button onClick={iniciarSesion}>Ingresar</button>
        </div>
    );

}