import React from "react";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';
import { Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';

export default function ModalEditarPromociones(props) {

    const { promociones, setPromociones } = props;
    const { detallePromocion, setDetallePromocion } = props;
    const { editarPromocion, setEditarPromocion } = props;
    const { promocionSeleccionada, setPromocionSeleccionada } = props;

    const handleChange = (e) => {
        const { name, value } = e.target;

        setPromocionSeleccionada((prevState) => ({
            ...prevState,
            [name]: value,
        }));
    };

    const abrirCerrarModalPromocionEditar = () => {
        setEditarPromocion(!editarPromocion);
    };

    const editarPromocionPut = async () => {
        const baseUrl1 = 'http://localhost/VentaCuponesPHP.API/Presentation/PromocionModificarController.php';
        var f = new FormData();
        f.append("IDPromocion", promocionSeleccionada.IDPromocion);
        f.append("FechaDeInicio", promocionSeleccionada.FechaDeInicio);
        f.append("FechaDeVencimiento", promocionSeleccionada.FechaDeVencimiento);
        f.append("Descuento", promocionSeleccionada.Descuento);
        f.append("IDEmpresa", promocionSeleccionada.IDEmpresa);
        f.append("IDCupon", promocionSeleccionada.IDCupon);
        f.append("Habilitado", promocionSeleccionada.Habilitado);
        f.append("METHOD", "PUT");
        await axios.post(baseUrl1, f, { params: { IDCupon: promocionSeleccionada.IDCupon } })
            .then(response => {
                var dataNueva = promociones;
                dataNueva.map(promocion => {
                    if (promocion.IDPromocion === promocionSeleccionada.IDPromocion) {
                        promocion.FechaDeInicio = promocionSeleccionada.FechaDeInicio;
                        promocion.FechaDeVencimiento = promocionSeleccionada.FechaDeVencimiento;
                        promocion.Descuento = promocionSeleccionada.Descuento;
                        promocion.IDEmpresa = promocionSeleccionada.IDEmpresa;
                        promocion.IDCupon = promocionSeleccionada.IDCupon;
                        promocion.Habilitado = promocionSeleccionada.Habilitado;
                    }
                });
                setPromociones(dataNueva);
                abrirCerrarModalPromocionEditar();
            }).catch(error => {
                console.log(error);
            });
    };

    return (
        <Modal isOpen={editarPromocion} className="modal-lg custom-modal" style={{ maxWidth: '90%', width: '90%' }}>
            <ModalHeader>Editar Promoción</ModalHeader>
            <ModalBody>
                <div className="form-group">
                    <label>ID Promoción: </label>
                    <br />
                    <input type="text" className="form-control" name="IDPromocion" value={promocionSeleccionada && promocionSeleccionada.IDPromocion} readOnly />
                    <br />
                    <label>Fecha de Inicio: </label>
                    <br />
                    <input type="date" className="form-control" name="FechaDeInicio" onChange={handleChange} value={promocionSeleccionada && promocionSeleccionada.FechaDeInicio} />
                    <br />
                    <label>Fecha de Vencimiento: </label>
                    <br />
                    <input type="date" className="form-control" name="FechaDeVencimiento" onChange={handleChange} value={promocionSeleccionada && promocionSeleccionada.FechaDeVencimiento} />
                    <br />
                    <label>Descuento: </label>
                    <br />
                    <input type="text" className="form-control" name="Descuento" onChange={handleChange} value={promocionSeleccionada && promocionSeleccionada.Descuento} />
                    <br />
                    <label>ID Empresa: </label>
                    <br />
                    <input type="text" className="form-control" name="IDEmpresa" onChange={handleChange} value={promocionSeleccionada && promocionSeleccionada.IDEmpresa} />
                    <br />
                    <label>ID Cupón: </label>
                    <br />
                    <input type="text" className="form-control" name="IDCupon" onChange={handleChange} value={promocionSeleccionada && promocionSeleccionada.IDCupon} />
                    <br />
                    <label>Habilitado: </label>
                    <br />
                    <input
                        type="checkbox"
                        className="form-check-input"
                        name="Habilitado"
                        checked={promocionSeleccionada && promocionSeleccionada.Habilitado === 1}
                        onChange={(e) => handleChange({ target: { name: 'Habilitado', value: e.target.checked ? 1 : 0 } })}
                    />
                    <br />
                </div>
            </ModalBody>
            <ModalFooter>
                <button className="btn btn-primary" onClick={editarPromocionPut}>Editar</button>
                <button className="btn btn-danger" onClick={abrirCerrarModalPromocionEditar}>Cancelar</button>
            </ModalFooter>
        </Modal>
    );
}
