import React, { useEffect, useState } from "react";
import { Modal, ModalBody, ModalFooter, ModalHeader } from "reactstrap";
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';

export default function ModalCrearCupon(props) {
    const { Cupones, setCupones } = props;
    const { detalleCupon, setDetalleCupon } = props;
    const { empresaSeleccionada, setEmpresaSeleccionada } = props;
    const { crearCupon, setCrearCupon } = props;
    const { categorias, setCategorias } = props;
    const [cuponCreado, setCuponCreado] = useState({
        Nombre: '',
        Imagen: '',
        Ubicacion: '',
        PrecioCupon: '',
        IDEmpresa: '',
        IDCategoria: '',
        Habilitado: 0
    });
    const [files, setFiles] = useState([]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setCuponCreado((prevState) => ({
            ...prevState,
            [name]: value,
        }));
        console.log(name, value);
    };

    const abrirCerrarModalCuponCrear = () => {
        setCrearCupon(!crearCupon);
    };

    const subirImagen = async () => {
        const imageRepositoriImage = 'https://api.cloudinary.com/v1_1/dks1ifnxa/image/upload';

        if (files.length > 0) {
            const data = new FormData();
            data.append('file', files[0]);
            data.append('upload_preset', 'ldgicqzu');
            data.append('cloud_name', 'dks1ifnxa');
            const response = await axios.post(imageRepositoriImage, data, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });
            if (response.status === 200) {
                cuponCreado.Imagen = response.data.url;
                return true;
            } else {
                return false;
            }
        }
        return false;
    };

    const validarCampos = () => {
        const nombreValido = validarNombreCupon(cuponCreado.Nombre);
        const ubicacionValida = validarUbicacion(cuponCreado.Ubicacion);
        const precioValido = validarPrecio(cuponCreado.PrecioCupon);

        if (!nombreValido) {
            console.error("Nombre inválido");
        }
        if (!ubicacionValida) {
            console.error("Ubicación inválida");
        }
        if (!precioValido) {
            console.error("Precio inválido");
        }

        return nombreValido && ubicacionValida && precioValido;
    };

    const validarNombreCupon = (nombre) => {
        return /^[a-zA-Z\s]{4,30}$/.test(nombre);
    };

    const validarUbicacion = (direccion) => {
        return /^[a-zA-Z\s]{10,200}$/.test(direccion);
    };

    const validarPrecio = (precio) => {
        return /^\d+\.\d{2}$/.test(precio);
    };

    const crearCuponInsert = async () => {
        if (validarCampos()) {
            if (await subirImagen()) {
                const baseUrl1 = 'http://localhost/VentaCuponesPHP.API/Presentation/CuponModificarController.php';
                var f = new FormData();
                f.append("Nombre", cuponCreado.Nombre);
                f.append("Imagen", cuponCreado.Imagen);
                f.append("Ubicacion", cuponCreado.Ubicacion);
                f.append("PrecioCupon", cuponCreado.PrecioCupon);
                f.append("IDEmpresa", empresaSeleccionada.IDEmpresa);
                f.append("IDCategoria", cuponCreado.IDCategoria);
                f.append("Habilitado", cuponCreado.Habilitado);
                f.append("METHOD", "POST");
                console.log("HABILITADO NUEVO CUPON: " + cuponCreado.Habilitado);
                await axios.post(baseUrl1, f)
                    .then(response => {
                        obtenerCuponesEmpresa();
                    }).catch(error => {
                        console.log(error);
                    });
            } else {
                alert('No se pudo subir la imagen');
            }
        } else {
            alert('Datos inválidos');
        }
    };

    const cargarImagen = (evento) => {
        setFiles(evento.target.files);
    };

    const obtenerCuponesEmpresa = async () => {
        try {
            const baseUrl1 = 'http://localhost/VentaCuponesPHP.API/Presentation/EmpresaLecturaController.php';
            const response = await axios.get(baseUrl1, { params: { IdEmpresa: empresaSeleccionada.IDEmpresa } });

            if (response.status === 200) {
                setCupones(response.data);
                console.log(response.data);
            } else if (response.status === 404) {
                console.log('No se encontraron cupones para esta empresa');
            }
        } catch (error) {
            setCupones([]);
            console.error('Error al obtener los cupones:', error);
        }
    };

    return (
        <Modal isOpen={crearCupon} className="modal-lg custom-modal" style={{ maxWidth: '90%', width: '90%' }}>
            <ModalHeader>Crear Cupón</ModalHeader>
            <ModalBody>
                <div className="form-group">
                    <label>Nombre: </label>
                    <br />
                    <input type="text" className="form-control" name="Nombre" onChange={handleChange} />
                    <br />
                    <label>Imagen: </label>
                    <br />
                    <input type="file" className="form-control" name="Imagen" onChange={cargarImagen} />
                    <br />
                    <label>Ubicación: </label>
                    <br />
                    <input type="text" className="form-control" name="Ubicacion" onChange={handleChange} />
                    <br />
                    <label>Precio Cupón: </label>
                    <br />
                    <input type="text" className="form-control" name="PrecioCupon" onChange={handleChange} />
                    <br />
                    <label>Categorías: </label>
                    <br />
                    <select
                        className="form-control"
                        name="IDCategoria"
                        value={cuponCreado.IDCategoria}
                        onChange={handleChange}
                    >
                        <option value="">Seleccione una categoría</option>
                        {categorias.map((categoria) => (
                            <option key={categoria.IDCategoria} value={categoria.IDCategoria}>
                                {categoria.Nombre}
                            </option>
                        ))}
                    </select>
                    <br />
                    <label>Habilitado: </label>
                    <br />
                    <input
                        type="checkbox"
                        className="form-check-input"
                        name="Habilitado"
                        onChange={(e) => handleChange({ target: { name: 'Habilitado', value: e.target.checked ? 1 : 0 } })}
                    />
                    <br />
                </div>
            </ModalBody>
            <ModalFooter>
                <button className="btn btn-primary" onClick={crearCuponInsert}>Crear</button>
                <button className="btn btn-danger" onClick={abrirCerrarModalCuponCrear}>Cancelar</button>
            </ModalFooter>
        </Modal>
    );
}
