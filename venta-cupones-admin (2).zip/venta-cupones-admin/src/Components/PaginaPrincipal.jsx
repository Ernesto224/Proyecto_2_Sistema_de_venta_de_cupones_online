import React from "react";
import { useState } from "react";

export default function PaginaPrincipal(props) {
    const { estadoPagina, setEstadoPagina } = props;
    const inicioSesion = () => {
        setEstadoPagina(null);
    }
    return (
        <div>
            <h1>Pagina Principal</h1>
            <button onClick={inicioSesion}>Iniciar Sesion</button>
        </div>
    );
}