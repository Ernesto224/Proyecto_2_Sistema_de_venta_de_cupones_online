import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '../App.css';
export default function BarraMenu(props) {
    const { estadoPagina, setEstadoPagina, contenidoPagina, setContenidoPagina,
        detalleCategoria, setDetalleCategoria, detalleInsertarEmpresa,
        setDetalleInsertarEmpresa, datosUsuario, setDatosUsuario,
        cerrarSesion, setCerrarSesion,
        detallePromocion, setDetallePromocion,
        editarEmpresa, setEditarEmpresa } = props;

    const reiniciarValores = () => {
        setDetallePromocion(false);
    }

    return (
        <nav className="navbar navbar-expand-lg navbar-light bg-green-primary">
            <a className="navbar-brand text-white" href="#" onClick={() => setEstadoPagina('PaginaPrincipal')}>MiApp</a>
            <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarNav">
                <ul className="navbar-nav ml-auto">
                    <li className="nav-item">
                        <a className="nav-link text-white" href="#" onClick={() => sessionStorage.removeItem('Usuario') && setDatosUsuario({
                            NombreUsuario: '',
                            Contrasenia: '',
                            Admin: ''
                        }) && setCerrarSesion(true) && reiniciarValores}>Cerrar Sesión</a>
                    </li>
                    {datosUsuario && datosUsuario.Admin === true && (
                        <>
                            <li className="nav-item">
                                <a className="nav-link text-white" href="#" onClick={() => setDetalleInsertarEmpresa(!detalleInsertarEmpresa)}>Agregar Empresa</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link text-white" href="#" onClick={() => setDetalleCategoria(!detalleCategoria)}>Agregar Categoria</a>
                            </li>

                        </>
                    )}
                    {
                        datosUsuario && datosUsuario.Admin === false && (
                            <>
                                <li className="nav-item">
                                    <a className="nav-link text-white" href="#" onClick={() => setEditarEmpresa(!editarEmpresa)}>Editar Mis Datos</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link text-white" href="#" onClick={() => setDetallePromocion(true)}>Mis Promociones</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link text-white" href="#" onClick={() => setDetalleCategoria(!detalleCategoria)}>Agregar Categoria</a>
                                </li>
                            </>
                        )
                    }
                </ul>
            </div>
        </nav>
    );
}