import React, { useState } from "react";
import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import ModalEditarPromociones from "./ModalEditarPromociones";
import ModalCrearPromocion from "./ModalCrearPromocion";

export default function ModalPromociones(props) {
    const { empresaSeleccionada, setEmpresaSeleccionada } = props;
    const { detallePromocion, setDetallePromocion } = props;
    const { Cupones, setCupones } = props;
    const { promociones, setPromociones } = props;
    const [editarPromocion, setEditarPromocion] = useState(false);
    const [crearPromocion, setCrearPromocion] = useState(false);
    const [promocionSeleccionada, setPromocionSeleccionada] = useState({
        IDPromocion: '',
        FechaDeInicio: '',
        FechaDeVencimiento: '',
        Descuento: '',
        IDEmpresa: '',
        IDCupon: '',
        Habilitado: ''
    });

    const abrirCerrarModalEliminar = () => {
        setDetallePromocion(!detallePromocion);
    };

    const abrirCerrarModalCrearPromocion = () => {
        setCrearPromocion(!crearPromocion);
    };

    const eliminarPromocionDELETE = async (promocion) => {
        const baseUrl1 = 'http://localhost/VentaCuponesPHP.API/Presentation/PromocionModificarController.php';
        var f = new FormData();
        f.append("IDPromocion", promocion.IDPromocion);
        f.append("Estado", 0);
        f.append("METHOD", "DELETE");
        console.log(promocion.IDPromocion, promocion.Habilitado);

        try {
            const response = await axios.post(baseUrl1, f, { params: { IDPromocion: promocion.IDPromocion, Estado: 0 } });
            console.log(response);

            // Actualiza el estado de la promoción
            setPromociones(promociones.map(p => {
                if (p && p.IDPromocion === promocion.IDPromocion) {
                    return { ...p, Habilitado: p.Habilitado === 1 ? 0 : 1 };
                }
                return p;
            }));
        } catch (error) {
            console.log(error);
        }
    };

    const abrirCerrarEdicionPromocion = (promocion) => {
        setPromocionSeleccionada(promocion);
        setEditarPromocion(!editarPromocion);
    };

    return (
        <>
            <div className="seccion-promociones" style={{ backgroundColor: '#5c5c5c', color: 'white', padding: '20px', borderRadius: '10px' }}>
                <h2 style={{ color: 'white' }}>Detalle de Promoción</h2>
                <div className="table-responsive" style={{ maxHeight: '70vh' }}>
                    <table className="table table-striped table-bordered" style={{ backgroundColor: '#5c5c5c', color: 'white' }}>
                        <thead className="thead-dark" style={{ backgroundColor: '#787878' }}>
                            <tr>
                                <th>Fecha de Inicio</th>
                                <th>Fecha de Vencimiento</th>
                                <th>Descuento</th>
                                <th>Empresa</th>
                                <th>Cupón Asignado</th>
                                <th>Habilitado</th>
                                <th>Editar</th>
                                <th>Eliminar</th>
                            </tr>
                        </thead>
                        <tbody style={{ overflowY: 'auto' }}>
                            {promociones.map((promocion, index) => (
                                promocion ? (
                                    <tr key={promocion.IDPromocion || index}>
                                        <td>{promocion.FechaDeInicio}</td>
                                        <td>{promocion.FechaDeVencimiento}</td>
                                        <td>{promocion.Descuento}</td>
                                        <td>{promocion.IDEmpresa === empresaSeleccionada.IDEmpresa ? empresaSeleccionada.NombreEmpresa : 'Ningúna'}</td>
                                        <td>{Cupones.find(cupon => cupon.IDCupon === promocion.IDCupon)?.Nombre || 'Sin cúpon'}</td>
                                        <td>{promocion.Habilitado ? 'Sí' : 'No'}</td>
                                        <td>
                                            <button className="btn btn-primary mr-2" style={{ backgroundColor: '#787878', borderColor: '#5c5c5c', color: 'white' }} onClick={() => abrirCerrarEdicionPromocion(promocion)}>Editar</button>
                                        </td>
                                        <td>
                                            {promocion.Habilitado !== 0 ? <button className="btn btn-danger" style={{ backgroundColor: '#d9534f', borderColor: '#d43f3a', color: 'white' }} onClick={() => eliminarPromocionDELETE(promocion)}>Eliminar</button>
                                                : <button className="btn btn-danger" style={{ backgroundColor: '#d9534f', borderColor: '#d43f3a', color: 'white' }} disabled={true} onClick={() => eliminarPromocionDELETE(promocion)}>Eliminar</button>}
                                        </td>
                                    </tr>
                                ) : null
                            ))}
                        </tbody>
                    </table>
                </div>
                <br />
                <button className="btn btn-secondary" style={{ backgroundColor: '#b1b1b1', borderColor: '#787878', color: 'white' }} onClick={abrirCerrarModalEliminar}>Cerrar</button>
                <button className="btn btn-secondary" style={{ backgroundColor: '#b1b1b1', borderColor: '#787878', color: 'white' }} onClick={abrirCerrarModalCrearPromocion}>Crear Promoción</button>
            </div>
            {editarPromocion && (
                <ModalEditarPromociones
                    promociones={promociones}
                    setPromociones={setPromociones}
                    detallePromocion={detallePromocion}
                    setDetallePromocion={setDetallePromocion}
                    editarPromocion={editarPromocion}
                    setEditarPromocion={setEditarPromocion}
                    promocionSeleccionada={promocionSeleccionada}
                    setPromocionSeleccionada={setPromocionSeleccionada}
                />
            )}
            {crearPromocion && (
                <ModalCrearPromocion
                    promociones={promociones}
                    setPromociones={setPromociones}
                    detallePromocion={detallePromocion}
                    setDetallePromocion={setDetallePromocion}
                    crearPromocion={crearPromocion}
                    setCrearPromocion={setCrearPromocion}
                    empresaSeleccionada={empresaSeleccionada}
                />
            )}
        </>
    );
}
