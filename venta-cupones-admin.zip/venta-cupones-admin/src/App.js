import './App.css';
import { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import PaginaPrincipal from './Components/PaginaPrincipal';
import InicioSesion from './Components/InicioSesion';
import BarraMenu from './Components/BarraMenu';
import axios from 'axios';
import ModalCrearCategoria from './Components/ModalCrearCategoria';
import ModalAgregarEmpresa from './Components/ModalAgregarEmpresa';
import PaginaEmpresa from './Components/PaginaEmpresa';
import IngresarNuevasCredenciales from './Components/IngresarNuevasCredenciales';

function App() {
  const [estadoPagina, setEstadoPagina] = useState(
    sessionStorage.getItem('Usuario') ? 'PaginaPrincipal' : null
  );
  const [detalleCategoria, setDetalleCategoria] = useState(false);
  const [empresas, setEmpresas] = useState([]);
  const [contenidoPagina, setContenidoPagina] = useState(null);
  const [detalleInsertarEmpresa, setDetalleInsertarEmpresa] = useState(false);
  const [cerrarSesion, setCerrarSesion] = useState(true);
  const [detallePromocion, setDetallePromocion] = useState(false);
  const [detalleEmpresaUsuario, setDetalleEmpresaUsuario] = useState(() => {
    const savedEmpresa = localStorage.getItem('Empresa');
    return savedEmpresa ? JSON.parse(savedEmpresa) : {
      IDEmpresa: '',
      NombreEmpresa: '',
      DireccionFisica: '',
      CedulaFisicaJuridica: '',
      FechaCreacion: '',
      CorreoElectronico: '',
      Telefono: '',
      NombreUsuario: '',
      Contrasenia: '',
      Habilitado: '',
      CredencialesTemporales: ''
    };
  });
  const [datosUsuario, setDatosUsuario] = useState({
    NombreUsuario: '',
    Contrasenia: '',
    Admin: ''
  });

  const obtenerEmpresas = async () => {
    const urlEmpresa = 'http://localhost/VentaCuponesPHP.API/Presentation/EmpresaLecturaController.php';
    try {
      const response = await axios.get(urlEmpresa);
      setEmpresas(response.data);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    obtenerEmpresas();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      const sessionData = JSON.parse(sessionStorage.getItem('Usuario'));
      if (sessionData) {
        setEstadoPagina('PaginaPrincipal');
        setDatosUsuario(sessionData);
        setCerrarSesion(false);
      } else {
        setCerrarSesion(true);
        setEstadoPagina(null);
      }
      if (!datosUsuario.NombreUsuario && !datosUsuario.Contrasenia && !datosUsuario.Admin) {
        clearInterval(interval);
      }
    }, 100);

    return () => clearInterval(interval);
  }, [datosUsuario]);

  const handleCerrarSesion = () => {
    sessionStorage.removeItem('Usuario');
    localStorage.removeItem('Empresa');
    setDatosUsuario({
      NombreUsuario: '',
      Contrasenia: '',
      Admin: ''
    });
    setDetalleEmpresaUsuario({
      IDEmpresa: '',
      NombreEmpresa: '',
      DireccionFisica: '',
      CedulaFisicaJuridica: '',
      FechaCreacion: '',
      CorreoElectronico: '',
      Telefono: '',
      NombreUsuario: '',
      Contrasenia: '',
      Habilitado: '',
      CredencialesTemporales: ''
    });
    setCerrarSesion(true);
    setEstadoPagina(null);
  };

  return (
    <div className="App">
      {estadoPagina === 'PaginaPrincipal' && datosUsuario && datosUsuario.Admin === true && cerrarSesion !== true ? (
        <>
          <BarraMenu
            estadoPagina={estadoPagina}
            setEstadoPagina={setEstadoPagina}
            contenidoPagina={contenidoPagina}
            setContenidoPagina={setContenidoPagina}
            detalleInsertarEmpresa={detalleInsertarEmpresa}
            setDetalleInsertarEmpresa={setDetalleInsertarEmpresa}
            detalleCategoria={detalleCategoria}
            setDetalleCategoria={setDetalleCategoria}
            datosUsuario={datosUsuario}
            setDatosUsuario={setDatosUsuario}
            cerrarSesion={cerrarSesion}
            setCerrarSesion={setCerrarSesion}
            detallePromocion={detallePromocion}
            setDetallePromocion={setDetallePromocion}
          />
          <PaginaPrincipal
            empresas={empresas}
            setEmpresas={setEmpresas}
            datosUsuario={datosUsuario}
            setDatosUsuario={setDatosUsuario}
          />
        </>
      ) : datosUsuario && datosUsuario.Admin === false && cerrarSesion !== true && detalleEmpresaUsuario.CredencialesTemporales === 0 ? (
        <>
          <BarraMenu
            estadoPagina={estadoPagina}
            setEstadoPagina={setEstadoPagina}
            contenidoPagina={contenidoPagina}
            setContenidoPagina={setContenidoPagina}
            detalleInsertarEmpresa={detalleInsertarEmpresa}
            setDetalleInsertarEmpresa={setDetalleInsertarEmpresa}
            detalleCategoria={detalleCategoria}
            setDetalleCategoria={setDetalleCategoria}
            datosUsuario={datosUsuario}
            setDatosUsuario={setDatosUsuario}
            cerrarSesion={cerrarSesion}
            setCerrarSesion={setCerrarSesion}
            detallePromocion={detallePromocion}
            setDetallePromocion={setDetallePromocion}
          />
          <PaginaEmpresa
            datosUsuario={datosUsuario}
            setDatosUsuario={setDatosUsuario}
            detalleEmpresaUsuario={detalleEmpresaUsuario}
            setDetalleEmpresaUsuario={setDetalleEmpresaUsuario}
            detallePromocion={detallePromocion}
            setDetallePromocion={setDetallePromocion}
          />
        </>
      ) : detalleEmpresaUsuario.CredencialesTemporales === 1 && cerrarSesion !== true ? (
        <>
          <IngresarNuevasCredenciales
            datosUsuario={datosUsuario}
            setDatosUsuario={setDatosUsuario}
            detalleEmpresaUsuario={detalleEmpresaUsuario}
            setDetalleEmpresaUsuario={setDetalleEmpresaUsuario}
          />
        </>
      ) : sessionStorage.getItem('Usuario') === null ? (
        <header className="App-header">
          <InicioSesion
            estadoPagina={estadoPagina}
            setEstadoPagina={setEstadoPagina}
            datosUsuario={datosUsuario}
            setDatosUsuario={setDatosUsuario}
            detalleEmpresaUsuario={detalleEmpresaUsuario}
            setDetalleEmpresaUsuario={setDetalleEmpresaUsuario}
          />
        </header>
      ) : null}
      {detalleCategoria && (
        <ModalCrearCategoria
          detalleCategoria={detalleCategoria}
          setDetalleCategoria={setDetalleCategoria}
        />
      )}
      {detalleInsertarEmpresa && (
        <ModalAgregarEmpresa
          detalleInsertarEmpresa={detalleInsertarEmpresa}
          setDetalleInsertarEmpresa={setDetalleInsertarEmpresa}
          empresas={empresas}
          setEmpresas={setEmpresas}
        />
      )}
    </div>
  );
}

export default App;
