import logo from './logo.svg';
import './App.css';
import { useState } from 'react';
import InicioSesion from './Component/InicioSesion';
import PaginaPrincipal from './Component/PaginaPrincipal';

function App() {
  const [estadoPagina, setEstadoPagina] = useState(null);
  return (
    <div className="App">
      <header className="App-header">
        {estadoPagina === 'Sesion' ? (
          <>
          </>
        ) : estadoPagina === 'PaginaPrincipal' ? (
          <PaginaPrincipal setEstadoPagina={setEstadoPagina} estadoPagina={estadoPagina} />
        ) : (
          <InicioSesion estadoPagina={estadoPagina} setEstadoPagina={setEstadoPagina} />
        )}
      </header>
    </div >
  );
}

export default App;
