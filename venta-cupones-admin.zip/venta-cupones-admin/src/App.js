import './App.css';
import { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import PaginaPrincipal from './Components/PaginaPrincipal';
import InicioSesion from './Components/InicioSesion';
import BarraMenu from './Components/BarraMenu';
import axios from 'axios';
import ModalCrearCategoria from './Components/ModalCrearCategoria';
import ModalAgregarEmpresa from './Components/ModalAgregarEmpresa';
function App() {
  const [estadoPagina, setEstadoPagina] = useState(
    sessionStorage.getItem('Usuario') ? 'PaginaPrincipal' : null
  );
  const [detalleCategoria, setDetalleCategoria] = useState(false);
  const [empresas, setEmpresas] = useState([]);
  const [contenidoPagina, setContenidoPagina] = useState(null);
  const [detalleInsertarEmpresa, setDetalleInsertarEmpresa] = useState(false);
  const [datosUsuario, setDatosUsuario] = useState({
    NombreUsuario: '',
    Contrasenia: '',
    Admin: false
  });

  const obtenerEmpresas = async () => {
    const urlEmpresa = 'http://localhost/VentaCuponesPHP.API/Presentation/EmpresaLecturaController.php';
    try {
      const response = await axios.get(urlEmpresa);
      setEmpresas(response.data);
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    obtenerEmpresas();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      const sessionData = JSON.parse(sessionStorage.getItem('Usuario'));
      if (sessionData) {
        setEstadoPagina('PaginaPrincipal');
      } else {
        setEstadoPagina(null);
      }
    }, 100);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="App">
      {estadoPagina === 'PaginaPrincipal' ? (
        <>
          <BarraMenu estadoPagina={estadoPagina} setEstadoPagina={setEstadoPagina}
            contenidoPagina={contenidoPagina} setContenidoPagina={setContenidoPagina}
            detalleInsertarEmpresa={detalleInsertarEmpresa} setDetalleInsertarEmpresa={setDetalleInsertarEmpresa}
            detalleCategoria={detalleCategoria} setDetalleCategoria={setDetalleCategoria}
            datosUsuario={datosUsuario} setDatosUsuario={setDatosUsuario} />
          <PaginaPrincipal empresas={empresas} setEmpresas={setEmpresas} />
        </>
      ) : (
        <header className="App-header">
          <InicioSesion estadoPagina={estadoPagina} setEstadoPagina={setEstadoPagina}
            datosUsuario={datosUsuario} setDatosUsuario={setDatosUsuario} />
        </header>
      )}
      {detalleCategoria && (
        <ModalCrearCategoria detallCategoria={detalleCategoria} setDetalleCategoria={setDetalleCategoria} />
      )}
      {detalleInsertarEmpresa && (
        <ModalAgregarEmpresa
          detalleInsertarEmpresa={detalleInsertarEmpresa}
          setDetalleInsertarEmpresa={setDetalleInsertarEmpresa}
          empresas={empresas}
          setEmpresas={setEmpresas}
        />
      )}
    </div>
  );
}

export default App;
