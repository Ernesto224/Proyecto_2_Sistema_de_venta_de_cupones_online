import React, { useState } from "react";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';
import '../App.css';

export default function IngresarNuevasCredenciales(props) {
    const { datosUsuario, setDatosUsuario } = props;
    const { detalleEmpresaUsuario, setDetalleEmpresaUsuario } = props;
    const [nombreUsuario, setNombreUsuario] = useState(datosUsuario.NombreUsuario || "");
    const [contrasenia, setContrasenia] = useState(datosUsuario.Contrasenia || "");

    const ingresarNuevasCredenciasles = async (e) => {
        e.preventDefault();
        const baseUrl1 = 'http://localhost/VentaCuponesPHP.API/Presentation/EmpresaModificarController.php';
        var f = new FormData();
        f.append('IDEmpresa', detalleEmpresaUsuario.IDEmpresa);
        f.append('NombreUsuario', nombreUsuario);
        f.append('Contrasenia', contrasenia);
        f.append('METHOD', 'PUT_CREDENCIALES');
        try {
            await axios.post(baseUrl1, f);
            const nuevosDatosUsuario = { ...datosUsuario, NombreUsuario: nombreUsuario, Contrasenia: contrasenia };
            setDatosUsuario(nuevosDatosUsuario);
            sessionStorage.setItem('Usuario', JSON.stringify(nuevosDatosUsuario));

            const nuevosDatosEmpresaUsuario = { ...detalleEmpresaUsuario, CredencialesTemporales: 0 };
            setDetalleEmpresaUsuario(nuevosDatosEmpresaUsuario);
            localStorage.setItem('Empresa', JSON.stringify(nuevosDatosEmpresaUsuario));
        } catch (error) {
            console.error("Error al actualizar las credenciales:", error);
        }
    };

    return (
        <div className="modal show d-block" tabIndex="-1" style={{ backgroundColor: '#323232' }}>
            <div className="modal-dialog">
                <div className="modal-content" style={{ backgroundColor: '#5c5c5c' }}>
                    <div className="modal-header">
                        <h5 className="modal-title">Ingresar Nuevas Credenciales</h5>
                    </div>
                    <div className="modal-body">
                        <form onSubmit={ingresarNuevasCredenciasles}>
                            <div className="mb-3">
                                <label htmlFor="formNombreUsuario" className="form-label">Nombre de Usuario</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    id="formNombreUsuario"
                                    placeholder="Ingrese el nombre de usuario"
                                    value={nombreUsuario}
                                    onChange={(e) => setNombreUsuario(e.target.value)}
                                    required
                                />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="formContrasenia" className="form-label">Nueva Contraseña</label>
                                <input
                                    type="password"
                                    className="form-control"
                                    id="formContrasenia"
                                    placeholder="Ingrese la nueva contraseña"
                                    value={contrasenia}
                                    onChange={(e) => setContrasenia(e.target.value)}
                                    required
                                />
                            </div>
                            <button type="submit" style={{ backgroundColor: '#b1b1b1', color: 'white' }}>Guardar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}
