import React, { useState } from 'react';
import ModalDetalleEmpresa from './ModalDetalleEmpresa';
import ModalCupones from './ModaLCupones';
import axios from 'axios';
import ModalPromociones from './ModalPromociones';
import '../App.css';
export default function PaginaPrincipal(props) {
    const { empresas, setEmpresas } = props;
    const [editarEmpresa, setEditarEmpresa] = useState(false);
    const [Cupones, setCupones] = useState([]);
    const [promociones, setPromociones] = useState([]);
    const [detalleCupon, setDetalleCupon] = useState(false);
    const [detallePromocion, setDetallePromocion] = useState(false);
    const [empresaSeleccionada, setEmpresaSeleccionada] = useState({
        IDEmpresa: '',
        NombreEmpresa: '',
        DireccionFisica: '',
        CedulaFisicaJuridica: '',
        FechaCreacion: '',
        CorreoElectronico: '',
        Telefono: '',
        NombreUsuario: '',
        Contrasenia: '',
        Habilitado: '',
        CredencialesTemporales: '',
    });
    const obtenerCuponesEmpresa = async (empresa) => {
        try {
            const baseUrl1 = 'http://localhost/VentaCuponesPHP.API/Presentation/EmpresaLecturaController.php';
            const response = await axios.get(baseUrl1, { params: { IdEmpresa: empresa.IDEmpresa } });

            if (response.status === 200) {
                setCupones(response.data);
                console.log(response.data);
            } else if (response.status === 404) {
                console.log('No se encontraron cupones para esta empresa');
            }
        } catch (error) {
            setCupones([]);
            console.error('Error al obtener los cupones:', error);
        }
    };
    const obtenerPromocionesEmpresa = async (empresa) => {
        try {
            const baseUrl1 = 'http://localhost/VentaCuponesPHP.API/Presentation/PromocionLecturaController.php';
            const response = await axios.get(baseUrl1, { params: { id: empresa.IDEmpresa } });

            if (response.status === 200) {
                if (Array.isArray(response.data)) {
                    setPromociones(response.data);
                } else {
                    setPromociones([]);
                }
            } else if (response.status === 404) {
                setPromociones([]);
                console.log('No se encontraron promociones para esta empresa');
            }
        } catch (error) {
            setPromociones([]);
            console.error('Error al obtener los cupones:', error);
        }
    };
    const seleccionarEmpresa = (empresa, caso) => {
        if (caso === "Editar") {
            setEmpresaSeleccionada(empresa);
            setEditarEmpresa(!editarEmpresa);
        }

        if (caso === "Cupones") {
            setEmpresaSeleccionada(empresa);
            obtenerCuponesEmpresa(empresa);
            setDetalleCupon(!detalleCupon);
        }
        if (caso === "Promociones") {
            setEmpresaSeleccionada(empresa);
            obtenerPromocionesEmpresa(empresa);
            setDetallePromocion(!detallePromocion);
        }
    };

    return (
        <div className="pagina-principal">
            <div>
                <table className="table table-hover table-striped">
                    <thead className="thead-dark bg-primary text-white">
                        <tr>
                            <th>Nombre de la Empresa</th>
                            <th>Dirección Física</th>
                            <th>Cédula Física Jurídica</th>
                            <th>Fecha Creación</th>
                            <th>Correo Electrónico</th>
                            <th>Nombre de Usuario</th>
                            <th>Contraseña</th>
                            <th>Habilitado</th>
                            <th>Credenciales Temporales</th>
                            <th>Editar Empresa</th>
                            <th>Cupones Empresa</th>
                            <th>Promociones</th>
                        </tr>
                    </thead>
                    <tbody>
                        {empresas.map((empresa) => (
                            <tr key={empresa.IDEmpresa}>
                                <td>{empresa.NombreEmpresa}</td>
                                <td>{empresa.DireccionFisica}</td>
                                <td>{empresa.CedulaFisicaJuridica}</td>
                                <td>{empresa.FechaCreacion}</td>
                                <td>{empresa.CorreoElectronico}</td>
                                <td>{empresa.Telefono}</td>
                                <td>{empresa.Contrasenia}</td>
                                <td>{empresa.Habilitado}</td>
                                <td>{empresa.CredencialesTemporales}</td>
                                <td>
                                    <button
                                        className="btn btn-primary btn-sm"
                                        onClick={() => seleccionarEmpresa(empresa, "Editar")}
                                    >
                                        Editar
                                    </button>
                                </td>
                                <td>
                                    <button
                                        className="btn btn-success btn-sm"
                                        onClick={() => seleccionarEmpresa(empresa, "Cupones")}
                                    >
                                        Cupones
                                    </button>
                                </td>
                                <td>
                                    <button
                                        className="btn btn-warning btn-sm"
                                        onClick={() => seleccionarEmpresa(empresa, "Promociones")}
                                    >
                                        Promociones
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            <ModalDetalleEmpresa
                editarEmpresa={editarEmpresa}
                setEditarEmpresa={setEditarEmpresa}
                empresaSeleccionada={empresaSeleccionada}
                setEmpresaSeleccionada={setEmpresaSeleccionada}
                empresas={empresas}
                setEmpresas={setEmpresas}
            />
            <ModalCupones
                empresaSeleccionada={empresaSeleccionada}
                setEmpresaSeleccionada={setEmpresaSeleccionada}
                detalleCupon={detalleCupon}
                setDetalleCupon={setDetalleCupon}
                Cupones={Cupones}
                setCupones={setCupones}
            />
            <ModalPromociones
                empresaSeleccionada={empresaSeleccionada}
                setEmpresaSeleccionada={setEmpresaSeleccionada}
                detallePromocion={detallePromocion}
                setDetallePromocion={setDetallePromocion}
                promociones={promociones}
                setPromociones={setPromociones}
            />
        </div>
    );

}
