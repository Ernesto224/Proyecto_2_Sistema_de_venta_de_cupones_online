import React, { useState } from "react";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";

export default function ModalCrearCategoria(props) {
    const [nuevaCategoria, setNuevaCategoria] = useState({
        Nombre: '',
        Descripcion: ''
    });
    const { detallCategoria, setDetalleCategoria } = props;

    const handleChange = (e) => {
        const { name, value } = e.target;

        setNuevaCategoria((prevState) => ({
            ...prevState,
            [name]: value,
        }));
    };

    const crearCategoria = async () => {
        const url = 'http://localhost/VentaCuponesPHP.API/Presentation/CategoriaCuponModificarController.php';
        var f = new FormData();
        f.append('Nombre', nuevaCategoria.Nombre);
        f.append('Descripcion', nuevaCategoria.Descripcion);
        f.append('METHOD', 'POST');
        await axios.post(url, f)
            .then(response => {
                console.log("Categoría creada exitosamente", response);
                resetForm();
                setDetalleCategoria(!detallCategoria);
            })
            .catch(error => {
                console.error("Error al crear la categoría:", error);
            });
    };

    const resetForm = () => {
        setNuevaCategoria({
            Nombre: '',
            Descripcion: ''
        });
    };

    return (
        <div className={`modal ${detallCategoria ? 'show' : ''}`} style={{ display: detallCategoria ? 'block' : 'none' }} tabIndex="-1">
            <div className="modal-dialog">
                <div className="modal-content">
                    <div className="modal-header">
                        <h5 className="modal-title">Crear Categoría</h5>
                        <button type="button" className="btn-close" onClick={() => setDetalleCategoria(false)} aria-label="Close"></button>
                    </div>
                    <div className="modal-body">
                        <form>
                            <div className="mb-3">
                                <label htmlFor="Nombre" className="form-label">Nombre</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    id="Nombre"
                                    name="Nombre"
                                    value={nuevaCategoria.Nombre}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="Descripcion" className="form-label">Descripción</label>
                                <textarea
                                    className="form-control"
                                    id="Descripcion"
                                    name="Descripcion"
                                    value={nuevaCategoria.Descripcion}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                        </form>
                    </div>
                    <div className="modal-footer">
                        <button type="button" className="btn btn-secondary" onClick={() => setDetalleCategoria(false)}>Cerrar</button>
                        <button type="button" className="btn btn-primary" onClick={crearCategoria}>Crear Categoría</button>
                    </div>
                </div>
            </div>
        </div>
    );
}
