import { useState, useEffect } from "react";
import React from "react";
import axios from "axios";
import ModalCupones from "./ModalCupones";
import ModalPromociones from "./ModalPromociones";
import '../App.css';

export default function PaginaEmpresa(props) {
    const { datosUsuario, setDatosUsuario, detalleEmpresaUsuario, setDetalleEmpresaUsuario, detalleCategoria, setDetalleCategoria } = props;
    const [Cupones, setCupones] = useState([]);
    const [mostrarCupones, setMostrarCupones] = useState(true);
    const { detallePromocion, setDetallePromocion } = props;
    const [promociones, setPromociones] = useState([]);

    useEffect(() => {
        const obtenerCuponesEmpresa = async () => {
            try {
                const baseUrl1 = 'http://localhost/VentaCuponesPHP.API/Presentation/EmpresaLecturaController.php';
                const response = await axios.get(baseUrl1, { params: { IdEmpresa: detalleEmpresaUsuario.IDEmpresa } });

                if (response.status === 200) {
                    setCupones(response.data);
                    console.log(response.data);
                } else if (response.status === 404) {
                    console.log('No se encontraron cupones para esta empresa');
                }
            } catch (error) {
                setCupones([]);
                console.error('Error al obtener los cupones:', error);
            }
        };

        const obtenerPromocionesEmpresa = async () => {
            try {
                const baseUrl1 = 'http://localhost/VentaCuponesPHP.API/Presentation/PromocionLecturaController.php';
                const response = await axios.get(baseUrl1, { params: { id: detalleEmpresaUsuario.IDEmpresa } });

                if (response.status === 200) {
                    if (Array.isArray(response.data)) {
                        setPromociones(response.data);
                    } else {
                        setPromociones([]);
                    }
                } else if (response.status === 404) {
                    setPromociones([]);
                    console.log('No se encontraron promociones para esta empresa');
                }
            } catch (error) {
                setPromociones([]);
                console.error('Error al obtener las promociones:', error);
            }
        };

        if (detalleEmpresaUsuario.IDEmpresa) {
            obtenerCuponesEmpresa();
            obtenerPromocionesEmpresa();
        }
    }, [detalleEmpresaUsuario]);

    return (
        <div className="pagina-empresa" style={{ backgroundColor: '#5c5c5c', color: 'white', minHeight: '100vh', padding: '20px' }}>
            <>
                {detallePromocion === false && (
                    <ModalCupones
                        empresaSeleccionada={detalleEmpresaUsuario}
                        setEmpresaSeleccionada={setDetalleEmpresaUsuario}
                        detalleCupon={mostrarCupones}
                        setDetalleCupon={setMostrarCupones}
                        Cupones={Cupones}
                        setCupones={setCupones}
                    />
                )}
                {detallePromocion && (
                    <ModalPromociones
                        empresaSeleccionada={detalleEmpresaUsuario}
                        setEmpresaSeleccionada={setDetalleEmpresaUsuario}
                        detallePromocion={detallePromocion}
                        setDetallePromocion={setDetallePromocion}
                        promociones={promociones}
                        setPromociones={setPromociones}
                    />
                )}
            </>
        </div>
    );
}
