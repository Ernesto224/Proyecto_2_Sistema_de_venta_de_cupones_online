import React, { useEffect, useState } from "react";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';
import { Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';

export default function ModalCrearPromocion(props) {
    const { promociones, setPromociones } = props;
    const { detallePromocion, setDetallePromocion } = props;
    const { crearPromocion, setCrearPromocion } = props;
    const { empresaSeleccionada } = props;
    const [cupones, setCupones] = useState([]);
    const [promocionCreada, setPromocionCreada] = useState({
        FechaDeInicio: '',
        FechaDeVencimiento: '',
        Descuento: '',
        IDEmpresa: empresaSeleccionada.IDEmpresa,
        IDCupon: '',
        Habilitado: 0
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setPromocionCreada((prevState) => ({
            ...prevState,
            [name]: value
        }));
        console.log("HABILITADO PROMO: " + name, value);
    };

    const abrirCerrarModalPromocionCrear = () => {
        setCrearPromocion(!crearPromocion);
        setDetallePromocion(!detallePromocion);
    };

    useEffect(() => {
        if (empresaSeleccionada) {
            obtenerCuponesEmpresa();
        }
    }, [empresaSeleccionada]);

    const crearPromocionNueva = async () => {
        const baseUrl1 = 'http://localhost/VentaCuponesPHP.API/Presentation/PromocionModificarController.php';
        var f = new FormData();
        f.append("FechaDeInicio", promocionCreada.FechaDeInicio);
        f.append("FechaDeVencimiento", promocionCreada.FechaDeVencimiento);
        f.append("Descuento", promocionCreada.Descuento);
        f.append("IDEmpresa", promocionCreada.IDEmpresa);
        f.append("IDCupon", promocionCreada.IDCupon);
        console.log("PROMOCION ACTUALIZADA: " + promocionCreada.Habilitado);
        f.append("Habilitado", promocionCreada.Habilitado);
        f.append("METHOD", "POST");
        await axios.post(baseUrl1, f)
            .then(response => {
                if (response) {
                    var promocionesAux = [...promociones, promocionCreada];
                    setPromociones(promocionesAux);
                }
                console.log("ID NUEVA PROMO: " + response);
                abrirCerrarModalPromocionCrear();
            }).catch(error => {
                console.log(error);
            });
    };

    const obtenerCuponesEmpresa = async () => {
        try {
            const baseUrl1 = 'http://localhost/VentaCuponesPHP.API/Presentation/EmpresaLecturaController.php';
            const response = await axios.get(baseUrl1, { params: { IdEmpresa: empresaSeleccionada.IDEmpresa } });

            if (response.status === 200) {
                setCupones(response.data);
                console.log(response.data);
            } else if (response.status === 404) {
                console.log('No se encontraron cupones para esta empresa');
            }
        } catch (error) {
            setCupones([]);
            console.error('Error al obtener los cupones:', error);
        }
    };

    return (
        <Modal isOpen={crearPromocion} className="modal-lg custom-modal" style={{ maxWidth: '90%', width: '90%' }}>
            <ModalHeader>Editar Promoción</ModalHeader>
            <ModalBody>
                <div className="form-group">
                    <label>Fecha de Inicio: </label>
                    <br />
                    <input type="date" className="form-control" name="FechaDeInicio" value={promocionCreada.FechaDeInicio} onChange={handleChange} />
                    <br />
                    <label>Fecha de Vencimiento: </label>
                    <br />
                    <input type="date" className="form-control" name="FechaDeVencimiento" value={promocionCreada.FechaDeVencimiento} onChange={handleChange} />
                    <br />
                    <label>Descuento: </label>
                    <br />
                    <input type="text" className="form-control" name="Descuento" value={promocionCreada.Descuento} onChange={handleChange} />
                    <br />
                    <label>Cupón Asignado: </label>
                    <br />
                    <select className="form-control" name="IDCupon" value={promocionCreada.IDCupon} onChange={handleChange}>
                        {cupones.map(cupon => (
                            <option key={cupon.IDCupon} value={cupon.IDCupon}>
                                {cupon.Nombre}
                            </option>
                        ))}
                    </select>
                    <br />
                    <label>Habilitado: </label>
                    <br />
                    <input
                        type="checkbox"
                        className="form-check-input"
                        name="Habilitado"
                        onChange={(e) => handleChange({ target: { name: 'Habilitado', value: e.target.checked ? 1 : 0 } })}
                    />
                    <br />
                </div>
            </ModalBody>
            <ModalFooter>
                <button className="btn btn-primary" onClick={crearPromocionNueva}>Crear</button>
                <button className="btn btn-danger" onClick={abrirCerrarModalPromocionCrear}>Cancelar</button>
            </ModalFooter>
        </Modal>
    );
}
