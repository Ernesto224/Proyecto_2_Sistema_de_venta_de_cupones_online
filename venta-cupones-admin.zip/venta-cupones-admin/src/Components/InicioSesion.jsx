import React, { useState } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import logoInicioSesion from "../Img/logoInicioSesion.png";
export default function InicioSesion(props) {
    const { estadoPagina, setEstadoPagina } = props;
    const { datosUsuario, setDatosUsuario } = props;

    const handleChange = e => {
        const { name, value } = e.target;
        setDatosUsuario(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const baseUrlAdm = 'http://localhost/VentaCuponesPHP.API/Presentation/UsuarioAdminLecturaController.php';

    const iniciarSesion = async () => {
        const f = new FormData();
        console.log(datosUsuario.NombreUsuario + " " + datosUsuario.Contrasenia);
        f.append("NombreUsuario", datosUsuario.NombreUsuario);
        f.append("Contrasenia", datosUsuario.Contrasenia);
        f.append("METHOD", "POST");

        await axios.post(baseUrlAdm, f)
            .then(response => {
                if (response.data === true) {
                    console.log(response.data);
                    const usuario = {
                        NombreUsuario: datosUsuario.NombreUsuario,
                        Contrasenia: datosUsuario.Contrasenia,
                        Admin: true
                    };
                    sessionStorage.setItem('Usuario', JSON.stringify(usuario));
                    setEstadoPagina('PaginaPrincipal');
                    setDatosUsuario(usuario);
                } else {
                    iniciarSesionEmpresa();
                }
            }).catch(error => {
                console.log(error);
            });
    };

    const iniciarSesionEmpresa = async () => {
        const f = new FormData();
        console.log(datosUsuario.NombreUsuario + " " + datosUsuario.Contrasenia);
        f.append("NombreUsuario", datosUsuario.NombreUsuario);
        f.append("Contrasenia", datosUsuario.Contrasenia);
        f.append("METHOD", "GET");

        const baseUrlAdm = 'http://localhost/VentaCuponesPHP.API/Presentation/EmpresaLecturaController.php';

        try {
            const response = await axios.post(baseUrlAdm, f);
            if (response.data === true) {
                const empresaJSON = response.data;
                console.log(empresaJSON.IDEmpresa);
                const usuario = {
                    NombreUsuario: datosUsuario.NombreUsuario,
                    Contrasenia: datosUsuario.Contrasenia,
                    Admin: true
                };
                sessionStorage.setItem('Usuario', JSON.stringify(usuario));
                setEstadoPagina('PaginaPrincipal');
                setDatosUsuario(usuario);
            }
        } catch (error) {
            console.log(error);
        }
    }



    return (
        <div className="container">
            <div className="row justify-content-center align-items-center vh-100">
                <div className="col-md-4">
                    <div className="card p-4 shadow">
                        <div className="text-center mb-4">
                            <div className="mb-3">
                                <img
                                    src={logoInicioSesion}
                                    alt="User Icon"
                                    style={{ width: '220px', height: '200px' }}
                                />
                            </div>
                            <h1>Iniciar Sesión</h1>
                        </div>
                        <input
                            className="form-control mb-3"
                            name="NombreUsuario"
                            type="text"
                            placeholder="Nombre Usuario"
                            onChange={handleChange}
                        />
                        <input
                            className="form-control mb-3"
                            name="Contrasenia"
                            type="password"
                            placeholder="Contraseña"
                            onChange={handleChange}
                        />
                        <button className="btn btn-success w-100" onClick={iniciarSesion}>
                            Ingresar
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}
