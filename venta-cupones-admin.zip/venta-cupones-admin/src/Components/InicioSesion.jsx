import React from "react";
import axios from 'axios';
export default function inicioSesion(props) {
    const { estadoPagina, setEstadoPagina } = props;
    const baseUrl = 'http://localhost/VentaCuponesPHP.API/Presentation/UsuarioAdminLecturaController.php`';
    const iniciarSesion = async (NombreUsuario, Contrasenia) => {
        const f = new FormData();
        f.append("NombreUsuario", NombreUsuario);
        f.append("Contrasenia", Contrasenia);
        f.append("METHOD", "POST");
        await axios.get(baseUrl, f)
            .then(response => {

            }).catch(error => {
                console.log(error);
            });
        setEstadoPagina('PaginaPrincipal');
    };
    return (
        <div className="inicio-sesion">
            <h1>Iniciar Sesión</h1>
            <input className='input-text' type='text' placeholder='Nombre Usuario'></input>
            <input type='input-text' placeholder='Contraseña'></input>
            <button onClick={iniciarSesion}>Ingresar</button>
        </div>
    );

}