import React from "react";
import { Modal, ModalBody, ModalFooter, ModalHeader } from "reactstrap";
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
export default function ModalEditarCupon(props) {
    const { Cupones, setCupones } = props;
    const { detalleCupon, setDetalleCupon } = props;
    const { editarCupon, setEditarCupon } = props;
    const { cuponSeleccionado, setCuponSelecionado } = props;
    const handleChange = (e) => {
        const { name, value } = e.target;

        setCuponSelecionado((prevState) => ({
            ...prevState,
            [name]: value,
        }));
    };
    const abrirCerrarModalCuponEditar = () => {
        setEditarCupon(!editarCupon);
        setDetalleCupon(!detalleCupon);
    };



    const editarCuponPut = async () => {
        const baseUrl1 = 'http://localhost/VentaCuponesPHP.API/Presentation/CuponModificarController.php';
        var f = new FormData();
        f.append("IDCupon", cuponSeleccionado.IDCupon);
        f.append("Nombre", cuponSeleccionado.Nombre);
        f.append("Imagen", cuponSeleccionado.Imagen);
        f.append("Ubicacion", cuponSeleccionado.Ubicacion);
        f.append("PrecioCupon", cuponSeleccionado.PrecioCupon);
        f.append("IDEmpresa", cuponSeleccionado.IDEmpresa);
        f.append("IDCategoria", cuponSeleccionado.IDCategoria);
        f.append("Habilitado", cuponSeleccionado.Habilitado);
        f.append("METHOD", "PUT");
        await axios.post(baseUrl1, f, { params: { IDCupon: cuponSeleccionado.IDCupon } })
            .then(response => {
                var dataNueva = Cupones;
                dataNueva.map(cupon => {
                    if (cupon.IDCupon === cuponSeleccionado.IDCupon) {
                        cupon.Nombre = cuponSeleccionado.Nombre;
                        cupon.Imagen = cuponSeleccionado.Imagen;
                        cupon.Ubicacion = cuponSeleccionado.Ubicacion;
                        cupon.PrecioCupon = cuponSeleccionado.PrecioCupon;
                        cupon.IDEmpresa = cuponSeleccionado.IDEmpresa;
                        cupon.IDCategoria = cuponSeleccionado.IDCategoria;
                        cupon.Habilitado = cuponSeleccionado.Habilitado;
                    }
                });
                setCupones(dataNueva);
                abrirCerrarModalCuponEditar();
            }).catch(error => {
                console.log(error);
            });
    };
    return (
        <Modal isOpen={editarCupon} className="modal-lg custom-modal" style={{ maxWidth: '90%', width: '90%' }}>
            <ModalHeader>Editar Cupón</ModalHeader>
            <ModalBody>
                <div className="form-group">
                    <label>ID Cupon: </label>
                    <br />
                    <input type="text" className="form-control" name="IDCupon" value={cuponSeleccionado && cuponSeleccionado.IDCupon} readOnly />
                    <br />
                    <label>Nombre: </label>
                    <br />
                    <input type="text" className="form-control" name="Nombre" onChange={handleChange} value={cuponSeleccionado && cuponSeleccionado.Nombre} />
                    <br />
                    <label>Imagen: </label>
                    <br />
                    <input type="text" className="form-control" name="Imagen" onChange={handleChange} value={cuponSeleccionado && cuponSeleccionado.Imagen} />
                    <br />
                    <label>Ubicación: </label>
                    <br />
                    <input type="text" className="form-control" name="Ubicacion" onChange={handleChange} value={cuponSeleccionado && cuponSeleccionado.Ubicacion} />
                    <br />
                    <label>Precio Cupón: </label>
                    <br />
                    <input type="number" className="form-control" name="PrecioCupon" onChange={handleChange} value={cuponSeleccionado && cuponSeleccionado.PrecioCupon} />
                    <br />
                    <label>ID Empresa: </label>
                    <br />
                    <input type="text" className="form-control" name="IDEmpresa" onChange={handleChange} value={cuponSeleccionado && cuponSeleccionado.IDEmpresa} />
                    <br />
                    <label>ID Categoría: </label>
                    <br />
                    <input type="text" className="form-control" name="IDCategoria" onChange={handleChange} value={cuponSeleccionado && cuponSeleccionado.IDCategoria} />
                    <br />
                    <label>Habilitado: </label>
                    <br />
                    <input
                        type="checkbox"
                        className="form-check-input"
                        name="Habilitado"
                        checked={cuponSeleccionado && cuponSeleccionado.Habilitado === 1}
                        onChange={(e) => handleChange({ target: { name: 'Habilitado', value: e.target.checked ? 1 : 0 } })}
                    />
                    <br />
                </div>
            </ModalBody>
            <ModalFooter>
                <button className="btn btn-primary" onClick={editarCuponPut}>Editar</button>
                <button className="btn btn-danger" onClick={abrirCerrarModalCuponEditar}>Cancelar</button>
            </ModalFooter>
        </Modal>
    );

}