import React, { useState } from "react";
import { Modal, ModalHeader, ModalBody } from 'reactstrap';
import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import ModalEditarPromociones from "./ModalEditarPromociones";
import ModalCrearPromocion from "./ModalCrearPromocion";

export default function ModalPromociones(props) {
    const { empresaSeleccionada, setEmpresaSeleccionada } = props;
    const { detallePromocion, setDetallePromocion } = props;
    const { promociones, setPromociones } = props;
    const [editarPromocion, setEditarPromocion] = useState(false);
    const [crearPromocion, setCrearPromocion] = useState(false);
    const [promocionSeleccionada, setPromocionSeleccionada] = useState({
        IDPromocion: '',
        FechaDeInicio: '',
        FechaDeVencimiento: '',
        Descuento: '',
        IDEmpresa: '',
        IDCupon: '',
        Habilitado: ''
    });

    const abrirCerrarModalEliminar = () => {
        setDetallePromocion(!detallePromocion);
    };

    const abrirCerrarModalCrearPromocion = () => {
        setCrearPromocion(!crearPromocion);
        setDetallePromocion(!detallePromocion);
    };

    const eliminarPromocionDELETE = async (promocion) => {
        const baseUrl1 = 'http://localhost/VentaCuponesPHP.API/Presentation/PromocionModificarController.php';
        var f = new FormData();
        f.append("IDPromocion", promocion.IDPromocion);
        f.append("Estado", 0);
        f.append("METHOD", "DELETE");
        console.log(promocion.IDPromocion, promocion.Habilitado);

        try {
            const response = await axios.post(baseUrl1, f, { params: { IDPromocion: promocion.IDPromocion, Estado: 0 } });
            console.log(response);

            // Actualiza el estado de la promoción
            setPromociones(promociones.map(p => {
                if (p && p.IDPromocion === promocion.IDPromocion) {
                    return { ...p, Habilitado: p.Habilitado === 1 ? 0 : 1 };
                }
                return p;
            }));
        } catch (error) {
            console.log(error);
        }
    };

    const abrirCerrarEdicionPromocion = (promocion) => {
        setPromocionSeleccionada(promocion);
        setDetallePromocion(!detallePromocion);
        setEditarPromocion(!editarPromocion);
    };

    return (
        <>
            <Modal isOpen={detallePromocion} className="modal-lg custom-modal" style={{ maxWidth: '90%', width: '90%' }}>
                <ModalHeader>Detalle de Promocion</ModalHeader>
                <ModalBody>
                    <div className="table-responsive" style={{ maxHeight: '70vh' }}>
                        <table className="table table-striped table-bordered">
                            <thead className="thead-dark">
                                <tr>
                                    <th>Fecha de Inicio</th>
                                    <th>Fecha de Vencimiento</th>
                                    <th>Descuento</th>
                                    <th>ID Empresa</th>
                                    <th>ID Cupón</th>
                                    <th>Habilitado</th>
                                    <th>Editar</th>
                                    <th>Eliminar</th>
                                </tr>
                            </thead>
                            <tbody style={{ overflowY: 'auto' }}>
                                {promociones.map((promocion, index) => (
                                    promocion ? (
                                        <tr key={promocion.IDPromocion || index}>
                                            <td>{promocion.FechaDeInicio}</td>
                                            <td>{promocion.FechaDeVencimiento}</td>
                                            <td>{promocion.Descuento}</td>
                                            <td>{promocion.IDEmpresa}</td>
                                            <td>{promocion.IDCupon}</td>
                                            <td>{promocion.Habilitado}</td>
                                            <td>
                                                <button className="btn btn-primary mr-2" onClick={() => abrirCerrarEdicionPromocion(promocion)}>Editar</button>
                                            </td>
                                            <td>
                                                {promocion.Habilitado !== 0 ? <button className="btn btn-danger" onClick={() => eliminarPromocionDELETE(promocion)}>Eliminar</button>
                                                    : <button className="btn btn-danger" disabled={true} onClick={() => eliminarPromocionDELETE(promocion)}>Eliminar</button>}
                                            </td>
                                        </tr>
                                    ) : null
                                ))}
                            </tbody>
                        </table>
                    </div>
                    <br />
                    <button className="btn btn-secondary" onClick={abrirCerrarModalEliminar}>Cerrar</button>
                    <button className="btn btn-secondary" onClick={abrirCerrarModalCrearPromocion}>Crear Promocion</button>
                </ModalBody>
            </Modal>
            {editarPromocion && (
                <ModalEditarPromociones
                    promociones={promociones} setPromociones={setPromociones}
                    detallePromocion={detallePromocion} setDetallePromocion={setDetallePromocion}
                    editarPromocion={editarPromocion} setEditarPromocion={setEditarPromocion}
                    promocionSeleccionada={promocionSeleccionada} setPromocionSeleccionada={setPromocionSeleccionada}
                />
            )}
            {crearPromocion && (
                <ModalCrearPromocion
                    promociones={promociones} setPromociones={setPromociones}
                    detallePromocion={detallePromocion} setDetallePromocion={setDetallePromocion}
                    crearPromocion={crearPromocion} setCrearPromocion={setCrearPromocion}
                    empresaSeleccionada={empresaSeleccionada}
                />
            )}
        </>
    );
}
