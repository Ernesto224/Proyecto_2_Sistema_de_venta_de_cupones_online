import React, { useState, useEffect } from 'react';
import { Modal, ModalBody, ModalFooter, ModalHeader } from 'reactstrap';
import axios from 'axios';

export default function ModalDetalleEmpresa(props) {
    const { empresaSeleccionada, setEmpresaSeleccionada } = props;
    const { empresas, setEmpresas } = props;
    const { editarEmpresa, setEditarEmpresa } = props;
    const handleChange = (e) => {
        const { name, value } = e.target;

        setEmpresaSeleccionada((prevState) => ({
            ...prevState,
            [name]: value,
        }));
        console.log(empresaSeleccionada.Habilitado);
    };


    const editarDatosEmpresa = async () => {
        const baseUrl1 = 'http://localhost/VentaCuponesPHP.API/Presentation/EmpresaModificarController.php';
        var f = new FormData();
        f.append("IDEmpresa", empresaSeleccionada.IDEmpresa);
        f.append("NombreEmpresa", empresaSeleccionada.NombreEmpresa);
        f.append("DireccionFisica", empresaSeleccionada.DireccionFisica);
        f.append("CedulaFisicaJuridica", empresaSeleccionada.CedulaFisicaJuridica);
        f.append("FechaCreacion", empresaSeleccionada.FechaCreacion);
        f.append("CorreoElectronico", empresaSeleccionada.CorreoElectronico);
        f.append("Telefono", empresaSeleccionada.Telefono);
        f.append("NombreUsuario", empresaSeleccionada.NombreUsuario);
        f.append("Contrasenia", empresaSeleccionada.Contrasenia);
        f.append("Habilitado", empresaSeleccionada.Habilitado);
        f.append("CredencialesTemporales", empresaSeleccionada.CredencialesTemporales);
        f.append("METHOD", "PUT");
        await axios.post(baseUrl1, f, { params: { IDEmpresa: empresaSeleccionada.IDEmpresa } })
            .then(response => {
                var dataNueva = empresas;
                dataNueva.map(empresa => {
                    if (empresa.IDEmpresa === empresaSeleccionada.IDEmpresa) {
                        empresa.NombreEmpresa = empresaSeleccionada.NombreEmpresa;
                        empresa.DireccionFisica = empresaSeleccionada.DireccionFisica;
                        empresa.CedulaFisicaJuridica = empresaSeleccionada.CedulaFisicaJuridica;
                        empresa.FechaCreacion = empresaSeleccionada.FechaCreacion;
                        empresa.CorreoElectronico = empresaSeleccionada.CorreoElectronico;
                        empresa.Telefono = empresaSeleccionada.Telefono;
                        empresa.NombreUsuario = empresaSeleccionada.NombreUsuario;
                        empresa.Contrasenia = empresaSeleccionada.Contrasenia;
                        empresa.Habilitado = empresaSeleccionada.Habilitado;
                    }
                });
                setEmpresas(dataNueva);
                abrirCerrarModalEditar();
            }).catch(error => {
                console.log(error);
            });
    }

    const abrirCerrarModalEditar = () => {
        setEditarEmpresa(!editarEmpresa);
    };


    return (
        <div>
            <Modal isOpen={editarEmpresa}>
                <ModalHeader>Editar Empresa</ModalHeader>
                <ModalBody>
                    <div className="form-group">
                        <label>ID: </label>
                        <br />
                        <input type="text" className="form-control" name="IDEmpresa" value={empresaSeleccionada && empresaSeleccionada.IDEmpresa} readOnly />
                        <br />
                        <label>Nombre Empresa: </label>
                        <br />
                        <input type="text" className="form-control" name="NombreEmpresa" onChange={handleChange} value={empresaSeleccionada && empresaSeleccionada.NombreEmpresa} />
                        <br />
                        <label>Direccion Fisica: </label>
                        <br />
                        <input type="text" className="form-control" name="DireccionFisica" onChange={handleChange} value={empresaSeleccionada && empresaSeleccionada.DireccionFisica} />
                        <br />
                        <label>Cedula Fisica Juridica: </label>
                        <br />
                        <input type="text" className="form-control" name="CedulaFisicaJuridica" onChange={handleChange} value={empresaSeleccionada && empresaSeleccionada.CedulaFisicaJuridica} />
                        <br />
                        <label>Fecha Creacion: </label>
                        <br />
                        <input type="text" className="form-control" name="FechaCreacion" onChange={handleChange} value={empresaSeleccionada && empresaSeleccionada.FechaCreacion} />
                        <br />
                        <label>Correo Electronico: </label>
                        <br />
                        <input type="text" className="form-control" name="CorreoElectronico" onChange={handleChange} value={empresaSeleccionada && empresaSeleccionada.CorreoElectronico} />
                        <br />
                        <label>Telefono: </label>
                        <br />
                        <input type="text" className="form-control" name="Telefono" onChange={handleChange} value={empresaSeleccionada && empresaSeleccionada.Telefono && empresaSeleccionada.Telefono.replace(/(\d{4})(\d{4})/, '$1-$2')} pattern="[0-9]{4}-[0-9]{4}" />
                        <br />
                        <label>Nombre Usuario: </label>
                        <br />
                        <input type="text" className="form-control" name="NombreUsuario" onChange={handleChange} value={empresaSeleccionada && empresaSeleccionada.NombreUsuario} />
                        <br />
                        <label>Contraseña: </label>
                        <br />
                        <input type="text" className="form-control" name="Contrasenia" onChange={handleChange} value={empresaSeleccionada && empresaSeleccionada.Contrasenia} />
                        <br />
                        <label>Habilitado: </label>
                        <br />
                        <input
                            type="checkbox"
                            className="form-check-input"
                            name="Habilitado"
                            checked={empresaSeleccionada && empresaSeleccionada.Habilitado === 1}
                            onChange={(e) => handleChange({ target: { name: 'Habilitado', value: e.target.checked ? 1 : 0 } })}
                        />
                        <br />
                        <label>Credenciales Temporales: </label>
                        <br />
                        <input type="text" className="form-control" name="CredencialesTemporales" onChange={handleChange} value={empresaSeleccionada && empresaSeleccionada.CredencialesTemporales} />
                        <br />
                    </div>
                </ModalBody>
                <ModalFooter>
                    <button className="btn btn-primary" onClick={() => editarDatosEmpresa()}>Editar</button>{"   "}
                    <button className="btn btn-danger" onClick={() => abrirCerrarModalEditar()}>Cancelar</button>
                </ModalFooter>
            </Modal>
        </div>
    );
}
