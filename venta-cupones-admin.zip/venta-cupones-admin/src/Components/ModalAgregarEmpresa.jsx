import React, { useState } from "react";
import axios from "axios";
import { Modal, ModalHeader, ModalBody, ModalFooter, Button } from "reactstrap";

export default function ModalAgregarEmpresa(props) {
    const { detalleInsertarEmpresa, setDetalleInsertarEmpresa } = props;
    const { empresas, setEmpresas } = props;

    const [nuevaEmpresa, setNuevaEmpresa] = useState({
        NombreEmpresa: "",
        DireccionFisica: "",
        CedulaFisicaJuridica: "",
        FechaCreacion: "",
        CorreoElectronico: "",
        Telefono: "",
        NombreUsuario: "",
        Contrasenia: "",
        Habilitado: 0,
        CredencialesTemporales: 1
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setNuevaEmpresa(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const insertEmpresaNueva = async () => {
        const baseUrl = 'http://localhost/VentaCuponesPHP.API/Presentation/EmpresaModificarController.php';
        const formData = new FormData();
        for (let key in nuevaEmpresa) {
            formData.append(key, nuevaEmpresa[key]);
        }
        formData.append("METHOD", "POST");

        try {
            const response = await axios.post(baseUrl, formData);
            if (response.status === 200) {
                console.log("Empresa agregada exitosamente", response);
                //setDetalleInsertarEmpresa(false);
                resetearDatos();
            } else {
                console.error("Error al agregar la empresa: estado de respuesta no válido");
            }
        } catch (error) {
            console.error("Error al agregar la empresa:", error);
        }
    };
    const resetearDatos = () => {
        setNuevaEmpresa({
            NombreEmpresa: "",
            DireccionFisica: "",
            CedulaFisicaJuridica: "",
            FechaCreacion: "",
            CorreoElectronico: "",
            Telefono: "",
            NombreUsuario: "",
            Contrasenia: "",
            Habilitado: 0,
            CredencialesTemporales: 1
        });
    };

    return (
        <Modal isOpen={detalleInsertarEmpresa} toggle={() => setDetalleInsertarEmpresa(!detalleInsertarEmpresa)}>
            <ModalHeader>Agregar Nueva Empresa</ModalHeader>
            <ModalBody>
                <div className="form-group">
                    <label>Nombre Empresa:</label>
                    <input type="text" className="form-control" name="NombreEmpresa" value={nuevaEmpresa.NombreEmpresa} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Dirección Física:</label>
                    <input type="text" className="form-control" name="DireccionFisica" value={nuevaEmpresa.DireccionFisica} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Cédula Física/Jurídica:</label>
                    <input type="text" className="form-control" name="CedulaFisicaJuridica" value={nuevaEmpresa.CedulaFisicaJuridica} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Fecha de Creación:</label>
                    <input type="date" className="form-control" name="FechaCreacion" value={nuevaEmpresa.FechaCreacion} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Correo Electrónico:</label>
                    <input type="email" className="form-control" name="CorreoElectronico" value={nuevaEmpresa.CorreoElectronico} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Teléfono:</label>
                    <input type="tel" className="form-control" name="Telefono" value={nuevaEmpresa.Telefono} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Nombre de Usuario:</label>
                    <input type="text" className="form-control" name="NombreUsuario" value={nuevaEmpresa.NombreUsuario} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Contraseña:</label>
                    <input type="password" className="form-control" name="Contrasenia" value={nuevaEmpresa.Contrasenia} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Habilitado:</label>
                    <input type="checkbox" className="form-check-input" name="Habilitado" onChange={(e) => handleChange({ target: { name: 'Habilitado', value: e.target.checked ? 1 : 0 } })} />
                </div>
            </ModalBody>
            <ModalFooter>
                <Button color="primary" onClick={insertEmpresaNueva}>Agregar Empresa</Button>{' '}
                <Button color="secondary" onClick={() => setDetalleInsertarEmpresa(false)}>Cancelar</Button>
            </ModalFooter>
        </Modal>
    );
}
