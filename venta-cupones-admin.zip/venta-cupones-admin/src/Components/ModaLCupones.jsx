import React, { useState } from "react";
import { Modal, ModalHeader, ModalBody } from 'reactstrap';
import '../App.css';
import ModalEditarCupon from "./ModalEditarCupon";
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import ModalCrearCupon from "./ModalCrearCupon";
export default function ModalCupones(props) {
    const { empresaSeleccionada, setEmpresaSeleccionada } = props;
    const { Cupones, setCupones } = props;
    const { detalleCupon, setDetalleCupon } = props;
    const [editarCupon, setEditarCupon] = useState(false);
    const [crearCupon, setCrearCupon] = useState(false);
    const [cuponSeleccionado, setCuponSelecionado] = useState({
        IDCupon: '',
        Nombre: '',
        Imagen: '',
        Ubicacion: '',
        PrecioCupon: '',
        IDEmpresa: '',
        IDCategoria: '',
        Habilitado: ''
    });
    //*INPUT de tipo file para las imagenes
    const abrirCerrarModalEliminar = () => {
        setDetalleCupon(!detalleCupon);
    }
    const abrirCerrarModalCrearCupon = () => {
        setDetalleCupon(!detalleCupon);
        setCrearCupon(!crearCupon);
    }

    const eliminarCuponDELETE = async (cupon) => {
        setCuponSelecionado(cupon);
        const baseUrl1 = 'http://localhost/VentaCuponesPHP.API/Presentation/CuponModificarController.php';
        var f = new FormData();
        f.append("IDCupon", cupon.IDCupon);
        f.append("METHOD", "DELETE");
        console.log(cupon.IDCupon);

        try {
            const response = await axios.post(baseUrl1, f, { params: { IDCupon: cupon.IDCupon } });
            console.log(response);
            setCupones(Cupones.map(cuponAux => {
                if (cuponAux.IDCupon === cupon.IDCupon) {
                    return { ...cuponAux, Habilitado: cupon.Habilitado === 1 ? 0 : 0 };
                }
                return cuponAux;
            }));
        } catch (error) {
            console.log(error);
        }
    };


    const abrirCerrarEdicionCupon = (cupon) => {
        setCuponSelecionado(cupon);
        setDetalleCupon(!detalleCupon);
        setEditarCupon(!editarCupon);
    }

    return (
        <>
            <Modal isOpen={detalleCupon} className="modal-lg custom-modal" style={{ maxWidth: '90%', width: '90%' }}>
                <ModalHeader>Detalle de Cupón</ModalHeader>
                <ModalBody>
                    <div className="table-responsive" style={{ maxHeight: '70vh' }}>
                        <table className="table table-striped table-bordered">
                            <thead className="thead-dark">
                                <tr>
                                    <th>Nombre</th>
                                    <th>Imagen</th>
                                    <th>Ubicación</th>
                                    <th>PrecioCupon</th>
                                    <th>IDEmpresa</th>
                                    <th>IDCategoría</th>
                                    <th>Habilitado</th>
                                    <th>Editar</th>
                                    <th>Eliminar</th>
                                </tr>
                            </thead>
                            <tbody style={{ overflowY: 'auto' }}>
                                {Cupones.map((cupon) => (
                                    <tr key={cupon.IDCupon}>
                                        <td>{cupon.Nombre}</td>
                                        <td>{cupon.Imagen}</td>
                                        <td>{cupon.Ubicacion}</td>
                                        <td>{cupon.PrecioCupon}</td>
                                        <td>{cupon.IDEmpresa}</td>
                                        <td>{cupon.IDCategoria}</td>
                                        <td>{cupon.Habilitado}</td>
                                        <td>
                                            <button className="btn btn-primary mr-2" onClick={() => abrirCerrarEdicionCupon(cupon)}>Editar</button>
                                        </td>
                                        <td>
                                            {cupon.Habilitado === 1 ? <button className="btn btn-danger" onClick={() => eliminarCuponDELETE(cupon)}>Eliminar</button>
                                                : <button className="btn btn-danger" disabled={true} onClick={() => eliminarCuponDELETE(cupon)}>Eliminar</button>}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    <br />
                    <button className="btn btn-secondary" onClick={abrirCerrarModalEliminar}>Cerrar</button>
                    <button className="btn btn-secondary" onClick={abrirCerrarModalCrearCupon}>Crear Cupon</button>
                </ModalBody>
            </Modal>
            <ModalEditarCupon
                Cupones={Cupones} setCupones={setCupones}
                detalleCupon={detalleCupon} setDetalleCupon={setDetalleCupon}
                editarCupon={editarCupon} setEditarCupon={setEditarCupon}
                cuponSeleccionado={cuponSeleccionado} setCuponSelecionado={setCuponSelecionado}
            />
            {crearCupon && (
                <ModalCrearCupon
                    Cupones={Cupones} setCupones={setCupones}
                    detalleCupon={detalleCupon} setDetalleCupon={setDetalleCupon}
                    crearCupon={crearCupon} setCrearCupon={setCrearCupon}
                    empresaSeleccionada={empresaSeleccionada} setEmpresaSeleccionada={empresaSeleccionada}
                />
            )}
        </>
    );





} 
